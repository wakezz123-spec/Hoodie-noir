# NOIRHOOD — Hoodie Store

Website toko hoodie statis, responsif, dan siap di-deploy ke GitHub Pages atau Vercel.

## Fitur
- Landing page streetwear dark / minimal.
- 4 contoh produk dengan harga yang bisa diedit.
- Keranjang belanja dengan tambah/kurang jumlah.
- Checkout membuka WhatsApp admin dengan ringkasan pesanan.
- Tidak membutuhkan database, framework, atau instalasi package.

## Cara menjalankan
Buka `index.html` di browser.

## Mengubah produk dan harga
Edit array `products` di file `script.js`. Setiap produk punya:
- `name`: nama produk
- `color`: warna
- `price`: harga dalam rupiah (angka)
- `tag`: label produk
- `shade`: warna ilustrasi hoodie

## Mengubah nomor WhatsApp
Di bagian paling atas `script.js`, ubah:
`const WHATSAPP_NUMBER = "6285135751969";`

Gunakan format kode negara tanpa tanda `+`, spasi, atau angka 0 di depan.

## Deploy ke Vercel
1. Ekstrak ZIP ini.
2. Buat repository baru di GitHub dan upload seluruh isi folder (index.html, style.css, script.js, README.md).
3. Login ke Vercel, pilih **Add New → Project**.
4. Import repository GitHub tersebut.
5. Framework Preset pilih **Other**; Build Command dan Output Directory bisa dikosongkan/default.
6. Klik **Deploy**.

## Deploy ke GitHub Pages
1. Upload isi folder ke repository GitHub.
2. Buka **Settings → Pages**.
3. Pada Build and deployment, pilih **Deploy from a branch**.
4. Pilih branch `main` dan folder `/ (root)`, lalu Save.

## Catatan sebelum mulai jualan
Produk, harga, warna, dan ilustrasi hoodie di website ini adalah contoh/mockup. Ganti dengan foto produk asli, ukuran, stok, ongkir, dan kebijakan toko sebelum dipublikasikan. Checkout mengirim detail pesanan ke WhatsApp; pembayaran dan ongkir dikonfirmasi manual oleh admin.
