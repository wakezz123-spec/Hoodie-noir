// Ganti nomor WhatsApp di bawah jika nomor admin berubah.
const WHATSAPP_NUMBER = "6285135751969";
const products = [
  {id:1,name:"Shadow Essential Hoodie",color:"Jet Black",price:189000,tag:"BEST SELLER",shade:"#292b29"},
  {id:2,name:"Midnight Oversized Hoodie",color:"Washed Charcoal",price:219000,tag:"OVERSIZED",shade:"#454744"},
  {id:3,name:"Concrete Grey Hoodie",color:"Stone Grey",price:199000,tag:"NEW DROP",shade:"#777a75"},
  {id:4,name:"Night Shift Hoodie",color:"Deep Olive",price:209000,tag:"LIMITED",shade:"#343b2d"}
];
let cart = [];
const rupiah = n => new Intl.NumberFormat("id-ID",{style:"currency",currency:"IDR",maximumFractionDigits:0}).format(n);
const productsEl = document.getElementById("products");
products.forEach(p=>{
  const card=document.createElement("article");
  card.className="product-card";
  card.innerHTML=`<div class="product-image"><span class="product-tag">${p.tag}</span><div class="mini-hoodie" style="--hood:${p.shade};--accent:#c9ff55"><i class="mini-sleeve left"></i><i class="mini-sleeve right"></i><b class="mini-logo">N.</b></div></div><div class="product-info"><h3>${p.name}</h3><div class="product-meta"><span>${p.color}</span><strong>${rupiah(p.price)}</strong></div><button class="add-button" data-add="${p.id}">ADD TO BAG +</button></div>`;
  productsEl.appendChild(card);
});
productsEl.addEventListener("click",e=>{const id=Number(e.target.dataset.add);if(!id)return;const item=cart.find(x=>x.id===id);if(item)item.qty++;else cart.push({...products.find(p=>p.id===id),qty:1,size:"L"});renderCart();showToast("Added to your bag");});
const panel=document.getElementById("cartPanel");
function openCart(){document.body.classList.add("cart-open")}
function closeCart(){document.body.classList.remove("cart-open")}
document.getElementById("cartToggle").onclick=openCart;
document.getElementById("closeCart").onclick=closeCart;
document.getElementById("backdrop").onclick=closeCart;
function renderCart(){
  const count=cart.reduce((s,x)=>s+x.qty,0), total=cart.reduce((s,x)=>s+x.price*x.qty,0);
  document.getElementById("cartCount").textContent=count;
  document.getElementById("cartHeadingCount").textContent=`(${count})`;
  document.getElementById("subtotal").textContent=rupiah(total);
  const el=document.getElementById("cartItems");
  if(!cart.length){el.innerHTML='<p class="empty-cart">Your bag is empty. Find your everyday piece.</p>';return;}
  el.innerHTML=cart.map(x=>`<div class="cart-item"><div><h3>${x.name}</h3><p>${x.color} · ${rupiah(x.price)}</p><div class="qty"><button data-minus="${x.id}">−</button><span>${x.qty}</span><button data-plus="${x.id}">+</button><button class="remove" data-remove="${x.id}">REMOVE</button></div></div><strong>${rupiah(x.price*x.qty)}</strong></div>`).join("");
}
document.getElementById("cartItems").addEventListener("click",e=>{
 const plus=Number(e.target.dataset.plus),minus=Number(e.target.dataset.minus),remove=Number(e.target.dataset.remove);
 if(plus){cart.find(x=>x.id===plus).qty++;}
 if(minus){const x=cart.find(x=>x.id===minus);x.qty--;if(x.qty<=0)cart=cart.filter(y=>y.id!==minus);}
 if(remove)cart=cart.filter(x=>x.id!==remove);
 renderCart();
});
document.getElementById("checkout").onclick=()=>{
 if(!cart.length){showToast("Keranjang kamu masih kosong");return;}
 const lines=cart.map(x=>`- ${x.name} | Warna: ${x.color} | Size: ${x.size} | Qty: ${x.qty} | ${rupiah(x.price*x.qty)}`);
 const total=cart.reduce((s,x)=>s+x.price*x.qty,0);
 const msg=`Halo NOIRHOOD! Saya mau pesan hoodie:%0A${encodeURIComponent(lines.join("\n"))}%0A%0ASubtotal: ${encodeURIComponent(rupiah(total))}%0A%0ANama:%0AAlamat:%0AKecamatan/Kota:%0AMetode pembayaran:`;
 window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${msg}`,"_blank","noopener");
};
document.getElementById("footerWa").href=`https://wa.me/${WHATSAPP_NUMBER}`;
function showToast(message){const t=document.getElementById("toast");t.textContent=message;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),1800)}
